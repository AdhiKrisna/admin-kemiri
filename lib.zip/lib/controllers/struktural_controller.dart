  import 'package:admin_kemiri/models/struktural_model.dart';
import 'package:admin_kemiri/services/structural_service.dart';
import 'package:get/get.dart';

class StrukturalController extends GetxController {
  var structurals = <StrukturalModel>[].obs;
  var isLoading = true.obs;

  final provider = StructuralService();

  @override
  void onInit() {
    super.onInit();
    fetchData();
  }

  void fetchData() async {
    try {
      isLoading(true);
      var result = await provider.fetchStructurals();
      structurals.assignAll(result);
    } catch (e) {
      Get.snackbar("Error", "Failed to fetch data: $e");
    } finally {
      isLoading(false);
    }
  }
}
