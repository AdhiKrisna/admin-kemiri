import 'package:admin_kemiri/models/struktural_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class StructuralService {
  final String baseUrl = 'http://localhost:3000';

  Future<List<StrukturalModel>> fetchStructurals() async {
    final response = await http.get(Uri.parse('$baseUrl/structurals'));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => StrukturalModel.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load struktural');
    }
  }
}
