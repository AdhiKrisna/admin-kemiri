import 'package:admin_kemiri/bindings/home_binding.dart';
import 'package:admin_kemiri/pages/home_page.dart';
import 'package:admin_kemiri/routes/route_names.dart';
import 'package:get/get.dart';

class RoutePages {
  static List<GetPage> routes = [
    GetPage(
      name: RouteNames.home,
      page: () => const HomePage(),
      binding: HomeBinding(),
      transition: Transition.fadeIn,
    ),
  ];
}
