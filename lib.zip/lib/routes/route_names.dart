class RouteNames {
  static const String home = '/home';
  static const String struktural = '/struktural';
  static const String wisata = '/wisata';
  static const String komoditas = '/komoditas';
}