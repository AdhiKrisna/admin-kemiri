import 'package:admin_kemiri/controllers/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/state_manager.dart';

class HomePage extends GetView<HomeController> {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Admin Kemiri"),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),

      body: Center(child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width * 0.5,
            color: Colors.blue,
            child: TextButton(onPressed: controller.goToStruktural,
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              child: Text("Struktural"),
            ),
          ),
        ],
      )),
    );
  }
}
